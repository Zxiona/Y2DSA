<?php
define('WeatherAPIKey', 'a67f6401fd6fa2e768d27abc6719b257');
define('MapAPIKey', 'AIzaSyB2ur87DvIcq2ChL047ZHi8OsUlmuSser4');

$servername = "localhost"; // Change if using a remote server
$username = "root";        // Your MySQL username
$password = "";            // Your MySQL password
$dbname = "twin_city";     // Database name

// connection to sql server
$conn = new mysqli($servername, $username, $password);

// select database
$conn->select_db($dbname);

// llondon coordinates
$londonLat = 51.5074;
$londonLng = -0.1278;

// new york coordinates
$NYLat = 40.7128;
$NYLng = -74.0060;

$ldnpoi = "SELECT Place_ID, City_ID, Type_ID, Borough_ID, Name, Address, Latitude, Longitude, Description, Photos, Opening_time, Ending_time
            FROM Place_of_Interest
            WHERE City_ID = 1";
$ldnpois = $conn->query($ldnpoi);

$nypoi = "SELECT Place_ID, City_ID, Type_ID, Borough_ID, Name, Address, Latitude, Longitude, Description, Photos, Opening_time, Ending_time
            FROM Place_of_Interest
            WHERE City_ID = 2";
$nypois = $conn->query($nypoi);

// converts london POI to array
$ldnpoiData = [];
if ($ldnpois->num_rows > 0) {
    while ($ldnrow = $ldnpois->fetch_assoc()) {
        $ldnpoiData[] = $ldnrow;
    }
}

// converts new york POI to array
$nypoiData = [];
if ($nypois->num_rows > 0) {
    while ($row = $nypois->fetch_assoc()) {
        $nypoiData[] = $row;
    }
}

// close connection
$conn->close();

// user defined error function
function ErrorHandler($errno, $errstr, $errfile, $errline)
{
    $errorMessage = "[" . date("Y-m-d H:i:s") . "] Error [$errno]: $errstr in $errfile on line $errline\n";

    // Log error to a file
    error_log($errorMessage, 3, "error_log.txt");

    // Display user-friendly message for critical errors
    if ($errno == E_USER_ERROR) {
        die("<b>Critical Error:</b> A major error occurred. Please try again later.");
    } else {
        echo "<b>Warning:</b> A minor issue occurred. System is still operational.";
    }
}

// set error handler
set_error_handler("ErrorHandler");

// database connection eror handling
$conn = new mysqli($servername, $username, $password);
if ($conn->connect_error) {
    trigger_error("Database connection failed: " . $conn->connect_error, E_USER_ERROR);
}

// select database error handling
if (!$conn->select_db($dbname)) {
    trigger_error("Database selection failed: " . $conn->error, E_USER_ERROR);
}

// query for london error handling
$ldnpoi = "SELECT * FROM Place_of_Interest WHERE City_ID = 1";
$ldnpois = $conn->query($ldnpoi);
if (!$ldnpois) {
    trigger_error("Query failed: " . $conn->error, E_USER_WARNING);
}

// query new york error handling
$nypoi = "SELECT * FROM Place_of_Interest WHERE City_ID = 2";
$nypois = $conn->query($nypoi);
if (!$nypois) {
    trigger_error("Query failed: " . $conn->error, E_USER_WARNING);
}

// close connection error handling
if (!$conn->close()) {
    trigger_error("Database connection closing failed: " . $conn->error, E_USER_WARNING);
}
