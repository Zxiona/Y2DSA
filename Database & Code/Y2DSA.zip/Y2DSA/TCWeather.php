<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Twin Cities Weather</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

    <!-- Font Awesome -->
    <script src="https://kit.fontawesome.com/2434cfa3b9.js" crossorigin="anonymous"></script>

    <!-- Custom CSS -->
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <!-- navigation bar -->
    <?php include 'navbar.php'; ?>

    <div class="container py-5">
        <div class="row mb-4">
            <div class="col-12">
                <h1 class="text-center mb-4">Twin Cities Weather Forecast</h1>
                <p class="text-center">Current weather and 5-day forecast for our twin cities.</p>
            </div>
        </div>

        <?php
        // include config file for api key
        include "config.php";

        // include open weather file
        include "open_weather.php";
        ?>
    </div>

    <!-- weather comparison -->
    <?php if ($currentWeather1 && $currentWeather2): ?>
        <div class="container pb-5">
            <div class="row">
                <div class="col-12">
                    <div class="card shadow-sm">
                        <div class="card-header bg-primary text-white">
                            <h3 class="mb-0">Weather Comparison</h3>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Metric</th>
                                            <th><?php echo $city1; ?></th>
                                            <th><?php echo $city2; ?></th>
                                            <th>Difference</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Temperature</td>
                                            <td><?php echo round($currentWeather1['main']['temp']); ?>°C</td>
                                            <td><?php echo round($currentWeather2['main']['temp']); ?>°C</td>
                                            <td><?php echo round(abs($currentWeather1['main']['temp'] - $currentWeather2['main']['temp'])); ?>°C</td>
                                        </tr>
                                        <tr>
                                            <td>Humidity</td>
                                            <td><?php echo $currentWeather1['main']['humidity']; ?>%</td>
                                            <td><?php echo $currentWeather2['main']['humidity']; ?>%</td>
                                            <td><?php echo abs($currentWeather1['main']['humidity'] - $currentWeather2['main']['humidity']); ?>%</td>
                                        </tr>
                                        <tr>
                                            <td>Wind Speed</td>
                                            <td><?php echo $currentWeather1['wind']['speed']; ?> m/s</td>
                                            <td><?php echo $currentWeather2['wind']['speed']; ?> m/s</td>
                                            <td><?php echo round(abs($currentWeather1['wind']['speed'] - $currentWeather2['wind']['speed']), 1); ?> m/s</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- footer -->
    <footer class="bg-dark text-white py-4 mt-auto">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h5>Twin Cities Project</h5>
                    <p class="small">Map and weather application for twin cities.</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <p class="small">Weather data provided by <a href="https://openweathermap.org/" class="text-white">OpenWeatherMap</a></p>
                    <p class="small">© <?php echo date('Y'); ?> Twin Cities Project</p>
                </div>
            </div>
        </div>
    </footer>

    <!-- javascript bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</body>

</html>